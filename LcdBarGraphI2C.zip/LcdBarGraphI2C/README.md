LcdBarGraph
===========

An Arduino library to draw bar graph on a Liquid Chrystal display.

See page http://playground.arduino.cc/Code/LcdBarGraph for details.
